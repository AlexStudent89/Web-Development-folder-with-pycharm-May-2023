ToDoLst = []  # Create an empty list.
ToDoLst2 = ["Buy Maurice a Tea", "Study Essentials", "Buy some flowers"]
OtherLst = [1, 3, 5, 46, 143, 6, 8]

print(ToDoLst2)
print()

JobNum = 1
for Job in ToDoLst2:
    print(f"  {JobNum}. {Job}")
    JobNum += 1
print()
NewItem = input("Enter the new job for the ToDo list:  ")
ToDoLst2.append(NewItem)

 JobNum = 1
 for Job in ToDoLst2:
     print(f"  {JobNum}. {Job}")
     JobNum += 1
print()

ToDoLst2.pop()  # Remove the last item from the list
JobNum = 1
for Job in ToDoLst2:
    print(f"  {JobNum}. {Job}")
    JobNum += 1
print()

DelItem = int(input("Enter the list item to delete: "))
ToDoLst2.__delitem__(DelItem-1)
JobNum = 1
for Job in ToDoLst2:
    print(f"  {JobNum}. {Job}")
    JobNum += 1
print()


