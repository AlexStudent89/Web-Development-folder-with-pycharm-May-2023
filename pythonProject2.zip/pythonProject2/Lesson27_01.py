#  Comments
# Import Libraries

# Constants
BONUS = .01

# Functions
def CalcBonus(totalSales):
    bonus = totalSales * BONUS
    message = ""
    if totalSales < 5000.00:
        reduceBonus = (5000.00 - totalSales) * .17
        bonus -= reduceBonus
        message += "Under"
        print("bonus: " + str(bonus))
        print(message)

    elif totalSales < 100000:
        message += "Normal"
        print("bonus: " + str(bonus))
        print(message)

    else:
        bonus += 500.00
        message += "Extraordinary"
        print("bonus: " + str(bonus))
        print(message)
    return bonus, message


CalcBonus(4000)

