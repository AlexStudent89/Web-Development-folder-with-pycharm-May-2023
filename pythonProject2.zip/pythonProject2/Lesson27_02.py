# Mo's Graphing Program
# Written by Alex Ewida
# Date: July 12, 2023
import matplotlib.pyplot as plt
import numpy as np
def GraphSimpleLine():
    print()
    print("Graphing simple line")

    m = float(input("Enter a value for m: "))
    b = float(input("Enter a value for b: "))
    x = np.linspace("-10, 10, 100")
    y = (m*x) + b


    plt.plot(x, y)
    plt.xlabel("x")
    plt.ylabel("y")
    plt.title("graph of y = mx + b")
    plt.show()

def GraphParabolicFunction():
    print()
    print("Graphing parabolic function")

    a = float(input("Enter a value for a: "))
    b = float(input("Enter a value for b: "))
    c = float(input("Enter a value for c: "))
    x = np.linspace("-10, 10, 100")
    y = (a * x**2) + (b * x) + c

    plt.plot(x, y)
    plt.xlabel("x")
    plt.ylabel("y")
    plt.title("graph of y = ax2 + bx +c.")
    plt.show()

# Menu
def main():
    print()
    print("Mo's Graphing Program")
    print("1. Graphing a Simple Line")
    print("2. Graphing a Parabolic Function")
    print("3. Graphing a Wave Function")
    print("4. Graphing a Root Function.")
    print("5. Quit the program.")
    try:
        choice = int(input("   Enter choice (1-5): "))
    except:
        print("Error - choice is not a valid entry.")
    else:
        if choice == 1:
            GraphSimpleLine()
        elif choice == 2:
            GraphParabolicFunction()
        elif choice == 3:
            pass
        elif choice == 4:
            pass
        elif choice == 5:
            exit()

main()


