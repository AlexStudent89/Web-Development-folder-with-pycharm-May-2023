# Comment like a pro.
# Import required libraries
import datetime
import FormatValues as FV
CurDate = datetime.datetime.now()
# Initialize any counters or accumulators
InvCtr = 0
InvReorderCtr = 0
ZeroCtr = 0
TotCostAcc = 0
TotRetailAcc = 0

f = open("SummaryInv.dat", "r")
for InventoryData in f:
    InvLine = InventoryData.split(",")
    ProdCost = float(InvLine[3].strip())
    RetailPrice = float(InvLine[4].strip())
    QOH = int(InvLine[5].strip())
    ReorderPt = int(InvLine[6].strip())
    MaxLevel = int(InvLine[7].strip())
    Winter = InvLine[8].strip()
    Spring = InvLine[9].strip()
    Summer = InvLine[10].strip()
    Fall = InvLine[11].strip()
    NumSoldThisYear = int(InvLine[12].strip())
    NumSoldLastYear = int(InvLine[13].strip())

    InvCtr += 1
    if QOH < ReorderPt:
        InvReorderCtr += 1
    if QOH == 0:
        ZeroCtr += 1
    TotCostAcc += ProdCost * QOH
    TotRetailAcc += RetailPrice * QOH
    PotProfit = TotRetailAcc - TotCostAcc
f.close()
# Now print out the results
print()
print(f"ABC COMPANY - SUMMARY INVENTORY DATA AS OF {FV.FDateM(CurDate):<9s}")
print()
print(f"Total inventory items:      {InvCtr:>4d}    Total inventory cost:     {FV.FDollar2(TotCostAcc):>10s}")
print(f"Items to order:              {InvReorderCtr:>3d}    Total inventory retail:   {FV.FDollar2(TotRetailAcc):>10s}")
print(f"Items with 0 on hand:        {ZeroCtr:>3d}    Potential profit margin:  {FV.FDollar2(PotProfit):>10s}")