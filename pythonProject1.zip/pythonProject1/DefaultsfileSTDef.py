import json

# Define the default settings
defaults = {
    "invoice_number": 1856,
    "room_rate": 75.00,
    "hst_rate": 0.15,  # 15% as a decimal
    "early_check_in_rate": 12.00,
    "extra_bed_rate": 7.00,
    "extra_key_rate": 2.00,
    "late_check_out_rate": 12.00
}

# Replace 'STDef.dat' with the path and filename where you want to create the .dat file
file_path = 'STDef.dat'

# Writing the default settings to the .dat file as JSON
with open(file_path, 'w') as datfile:
    json.dump(defaults, datfile)